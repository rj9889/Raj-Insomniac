import os
from dotenv import load_dotenv
from google.genai import types

load_dotenv()

MODEL = os.getenv("MODEL")
BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # AURION/common -> AURION
DATA_DIR = os.path.join(BASE_DIR, "data")  # optional JSON fallback folder

# Deterministic, clean outputs
CLEAN_CFG = types.GenerateContentConfig(temperature=0)

# Sheets + MCP
# SHEET_ID = os.getenv("SHEET_ID")
# GOOGLE_APPLICATION_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
# GENAI_API_KEY = os.getenv("GENAI_API_KEY")