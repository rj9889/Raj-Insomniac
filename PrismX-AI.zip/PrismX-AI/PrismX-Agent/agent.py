# google_maps_mcp_agent/agent.py
import sys, os
sys.path.append(os.path.dirname(__file__))

from common.rbac import (
    normalize_role_phrase, set_role, get_role, identity_policy, redact_row,
    ROLE_ANALYST, ROLE_ASSOC_DIR, ROLE_GOVERNOR
)

from google.adk import Agent
from google.adk.tools.tool_context import ToolContext
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StdioServerParameters, StdioConnectionParams

from common.config import MODEL, CLEAN_CFG, DATA_DIR
from common.data_loader import load_json_data_tool

from subagents.classification_agent import classification_agent
from subagents.ui_feedback_agent import ui_feedback_agent
from subagents.learning_agent import learning_agent
from subagents.governance_agent import governance_agent
from subagents.executive_summary_agent import executive_summary_agent
from subagents.query_agent import query_agent

# ---------- Configure MCP (Python server) ----------
MCP_PY_PATH = os.path.join(os.path.dirname(__file__), "common", "mcp", "mcp_sheets_server.py")

MCP_SHEETS = MCPToolset(
    connection_params=StdioConnectionParams(
        server_params=StdioServerParameters(
            command="python3",
            args=[MCP_PY_PATH],
            env={
                "GOOGLE_APPLICATION_CREDENTIALS": "/home/student_02_ed16d26ba24b/PrismX-AI/PrismX-Agent/common/mcp/service_account.json",
                "SHEET_ID": "1xuBznN7IRgsMkmGRT4lTFf2yry4caqgITdvzZfFXIJM",
                # Optional: put API key if you have it; otherwise local fallback embedding will be used
                # "GENAI_API_KEY": "YOUR_API_KEY",
            },
        ),
        timeout=300000,
    )
)

# ---------- Data ensure tool ----------

def ensure_data(tool_context: ToolContext) -> dict:
    need_keys = ("employees","cmdb","activity_logs","weights")
    missing = []
    for k in need_keys:
        if k not in tool_context.state:
            missing.append(k)
        else:
            v = tool_context.state.get(k)
            if isinstance(v, list) and len(v) == 0:
                missing.append(k)

    if missing:
        return {"status":"needs_load","missing":missing}
    return {"status":"already_loaded"}


def set_user_role(tool_context: ToolContext, role: str) -> dict:
    role = (role or "").strip().lower()
    if role not in (ROLE_ANALYST, ROLE_ASSOC_DIR, ROLE_GOVERNOR):
        return {"status": "error", "error": f"unknown role '{role}'"}
    set_role(tool_context.state, role)
    return {"status": "ok", "role": role}

def clear_user_role(tool_context: ToolContext) -> dict:
    set_role(tool_context.state, ROLE_ANALYST)
    return {"status": "ok", "role": ROLE_ANALYST}


def stage_sources(tool_context: ToolContext, sources: dict) -> dict:
    """
    Persist sources returned from MCP `prism_read_all_sources` into state.
    Accepts either:
      {"sources": {...}}  OR the inner {...} directly.
    """
    payload = sources.get("sources", sources) or {}
    employees = payload.get("employees", [])
    cmdb = payload.get("cmdb", [])
    activity_logs = payload.get("activity_logs", [])
    taxonomy_rows = payload.get("taxonomy_weights", [])

    # Build weights dict-of-dicts: weights[category][label] = float(weight)
    weights = {}
    for row in taxonomy_rows:
        cat = str(row.get("category", "")).strip()
        lab = str(row.get("label", "")).strip()
        try:
            w = float(row.get("weight", 0))
        except Exception:
            w = 0.0
        if cat and lab:
            weights.setdefault(cat, {})[lab] = w

    tool_context.state["employees"] = employees
    tool_context.state["cmdb"] = cmdb
    tool_context.state["activity_logs"] = activity_logs
    tool_context.state["weights"] = weights
    tool_context.state["taxonomy_weights"] = taxonomy_rows


    return {
        "status": "staged",
        "counts": {
            "employees": len(employees),
            "cmdb": len(cmdb),
            "activity_logs": len(activity_logs),
            "taxonomy_weights": sum(len(v) for v in weights.values()),
        },
    }

def rbac_bind_helpers(tool_context: ToolContext) -> dict:
    # store identifiers not actual functions
    tool_context.state["_rbac_identity_policy"] = "identity_policy_enabled"
    tool_context.state["_rbac_redact_row"] = True    # feature flag style
    return {"status": "ok"}

# ---------- Root Agent ----------
root_agent = Agent(
    name="project_prism_assistant",
    model=MODEL,
    description="Unified orchestrator for Prism — coordinates sub-agents + MCP Sheets.",
    instruction=f"""
You are Project Prism — an executive-friendly assistant that coordinates
Google Sheets data via MCP and specialized sub-agents.

RBAC:
- If the user message contains a role phrase, immediately call local tool
  `set_user_role` with:
    • "governor" when they say "I am governor".
    • "associate_director" when they say "I am associate director".
    • "analyst" when they say "I am analyst".
  Confirm the active role with one sentence.
- When presenting any records, obey identity policy from state:
  • analyst: hide name and worker_id
  • associate_director: show name, hide worker_id
  • governor: show both
  (The sub-agents can use _rbac_redact_row() attached in state.)

Data Loading Protocol (always run silently before any task if needed):
1) Call MCP tool `prism_ensure_tabs` (no args)
2) Call MCP tool `prism_read_all_sources` (no args)
3) Call local tool `stage_sources` with the full result

Vector Auto Mode (always silent after classification finishes):
- If vectors are empty or new rows appeared in employees/cmdb/activity_logs,
  call MCP tool `prism_vector_autobuild` (no args).

Task Routing:
- If user asks to classify or run a cycle: run ensure_data → classification → governance → learning → executive summary.
- For analytics/Q&A: if data missing, first run the Data Loading Protocol silently.
- For feedback: persist via UI Feedback agent; also call MCP `prism_append_feedback` when appropriate.
- For governance queue writes: also call MCP `prism_append_governance`.
- After learning updates: call MCP `prism_upsert_taxonomy` with upserts.

Privacy & Tone:
- Obey RBAC for identities. Keep responses concise & executive-ready.

Whenever user asks summary / insights / analytics:
Before calling executive_summary_agent:
ALWAYS do:
1) ensure_data
2) if needs_load → run data loading protocol steps silently
3) ALWAYS run classification_agent first to populate state["classified"]
Only after classification succeeded → run executive_summary_agent.

""",

    sub_agents=[
        classification_agent,
        ui_feedback_agent,
        learning_agent,
        governance_agent,
        executive_summary_agent,
        query_agent,
    ],
    tools=[ensure_data, stage_sources, rbac_bind_helpers, set_user_role, clear_user_role, load_json_data_tool, MCP_SHEETS],
    generate_content_config=CLEAN_CFG,
)

