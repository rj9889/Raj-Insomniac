import re
from google.adk import Agent
from google.adk.tools.tool_context import ToolContext
from callback_logging import log_query_to_model, log_model_response
from common.config import MODEL, CLEAN_CFG, MCP_SHEETS
from common.utils import percent, parse_days_window
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StdioServerParameters, StdioConnectionParams

import sys, os

# BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # go up from subagents
# MCP_PY_PATH = os.path.join(BASE_DIR, "common", "mcp", "mcp_sheets_server.py")



# MCP_SHEETS = MCPToolset(
#     connection_params=StdioConnectionParams(
#         server_params=StdioServerParameters(
#             command="python3",
#             args=[MCP_PY_PATH],
#             env={
#                 "GOOGLE_APPLICATION_CREDENTIALS": "/home/student_02_149201cd617f/PrismX-AI/PrismX-Agent/common/mcp/service_account.json",
#                 "SHEET_ID": "1xuBznN7IRgsMkmGRT4lTFf2yry4caqgITdvzZfFXIJM",
#                 # Optional: put API key if you have it; otherwise local fallback embedding will be used
#                 # "GENAI_API_KEY": "YOUR_API_KEY",
#             },
#         ),
#         timeout=300000,
#     )
# )

def _sum_by(records, key):
    totals = {}
    for r in records:
        k = r.get(key)
        if not k: continue
        totals[k] = totals.get(k, 0) + float(r.get("duration_seconds",0))
    return dict(sorted(totals.items(), key=lambda x:x[1], reverse=True))

# RBAC wrapper




# def set_user_role(tool_context: ToolContext, role: str) -> dict:
#     role = (role or "").strip().lower()
#     if role not in (ROLE_ANALYST, ROLE_ASSOC_DIR, ROLE_GOVERNOR):
#         return {"status": "error", "error": f"unknown role '{role}'"}
#     set_role(tool_context.state, role)
#     return {"status": "ok", "role": role}

# def clear_user_role(tool_context: ToolContext) -> dict:
#     set_role(tool_context.state, ROLE_ANALYST)
#     return {"status": "ok", "role": ROLE_ANALYST}

async def answer_query(tool_context: ToolContext, question: str) -> dict:

    # Ensure sources & classifications exist
    if "activity_logs" not in tool_context.state:
        # model will call `prism_read_all_sources` automatically (per instruction)
        pass
    if "classified" not in tool_context.state:
        # model will call Classification tool
        pass

    cl = tool_context.state.get("classified", [])
    if not cl:
        return {"answer":"No data available after classification."}

    ql = question.lower()
    start, end, label = parse_days_window(ql)

    filtered = [r for r in cl if start <= str(r.get("date","")) <= end] or cl

    # Dev vs Meetings
    if ("development" in ql or "dev " in ql) and ("meeting" in ql or "meetings" in ql):
        by_work = _sum_by(filtered, "work_type")
        return {"answer": f"{label.title()} — Development: {by_work.get('Development',0)/3600:.1f} hrs, Meetings: {by_work.get('Meeting',0)/3600:.1f} hrs."}

    # Top technologies
    if ("top" in ql or "most" in ql) and ("technolog" in ql):
        by_tech = _sum_by(filtered, "technology")
        top = list(by_tech.items())[:5]
        return {"answer":"Top technologies by time ("+label+"):\n"+"\n".join([f"- {k}: {v/3600:.1f} hrs" for k,v in top])}

    # Confidence
    if "confidence" in ql or "uncertain" in ql:
        confs = [float(r.get("confidence",1.0)) for r in filtered]
        avg = sum(confs)/len(confs)
        low = sum(1 for c in confs if c<0.75)/len(confs)
        return {"answer": f"{label.title()} — Avg confidence: {avg:.3f}; low-confidence share: {percent(low)}."}

    # Employee
    m_emp = re.search(r"(employee|worker)\s+([AEC]-\d{4}|AD-\d{3})", ql)
    if m_emp:
        wid = m_emp.group(2).upper()
        sub = [r for r in filtered if str(r.get("worker_id","")).upper()==wid]
        if not sub: return {"answer": f"No rows for {wid} {label}."}
        by_work = _sum_by(sub, "work_type")
        return {"answer": f"{wid} — time by work type ({label}):\n"+"\n".join([f"- {k}: {v/3600:.1f} hrs" for k,v in by_work.items()])}

    # Technology specific
    m_tech = re.search(r"(time|hours).*(on|in)\s+([a-z0-9\-/\s]+)$", ql)
    if m_tech:
        name = m_tech.group(3).strip().lower()
        hrs = sum(float(r.get("duration_seconds",0)) for r in filtered if str(r.get("technology","")).lower()==name)/3600
        return {"answer": f"{label.title()} — Time on {name.title()}: {hrs:.1f} hrs."}

    # Role-based if employees present
    if "role" in ql:
        emps = tool_context.state.get("employees", [])
        role_map = {e.get("worker_id"): e.get("role","Unknown") for e in emps}
        by_role = {}
        for r in filtered:
            role = role_map.get(r.get("worker_id"), "Unknown")
            by_role[role] = by_role.get(role,0)+float(r.get("duration_seconds",0))
        top = sorted(by_role.items(), key=lambda x:x[1], reverse=True)[:10]
        return {"answer": f"Top roles by time ({label}):\n"+"\n".join([f"- {k}: {v/3600:.1f} hrs" for k,v in top])}

    # Fallback overview
    by_work = _sum_by(filtered, "work_type")
    by_tech = list(_sum_by(filtered, "technology").items())[:5]
    confs = [float(r.get("confidence",1.0)) for r in filtered]
    avg = sum(confs)/len(confs); low = sum(1 for c in confs if c<0.75)/len(confs)
    lines = [
        f"Overview ({label}):",
        "Work types (hrs):",
        *[f"- {k}: {v/3600:.1f} hrs" for k,v in by_work.items()],
        "Top technologies (hrs):",
        *[f"- {k}: {v/3600:.1f} hrs" for k,v in by_tech],
        f"Avg confidence: {avg:.3f}; low-confidence share: {percent(low)}",
    ]
    return {"answer":"\n".join(lines)}

query_agent = Agent(
    name="query_agent",
    model=MODEL,
    description="Primary Q&A agent for data questions. Attempts to answer any employees, activity logs, cmdb , roles factual, counting, metric, or analytical query using loaded state. If not confident or required data is missing, delegate control back to the root agent.",
    instruction="""
You are the Query module.

Behavior:
1) If source tables are not in memory, call the MCP tools to fetch them
2) If source tables missing, call MCP tool `prism_read_all_sources` and place results into:
   • state["employees"], state["cmdb"], state["activity_logs"], state["weights_raw"] (taxonomy list)
   Then reshape `weights_raw` into dict-of-dicts in state["weights"] if needed.
3) If classifications missing, call the Classification tool.
4) Support natural time windows: “this week”, “last week”, “last N days” ans other format also also.
5) If you cannot answer confidently OR required data missing, output EXACTLY this literal string: ESCALATE_TO_ROOT
 -No explanation, no narrative, no apology.
-The root agent will take over after this signal.
6) Format outputs concisely (hours to 1 decimal, confidence to 3 decimals, percents to 1 decimal).
7) Never mention internal tools/agents; respond as a single assistant.
8) If the question is outside the scope of Prism, the agent must still provide a helpful generic/general answer instead of refusing.
9) If not answerable, say why briefly and what is needed.
    """,
    tools=[answer_query,MCP_SHEETS],
    before_model_callback=log_query_to_model,
    after_model_callback=log_model_response,
    generate_content_config=CLEAN_CFG,
)
